import { lazy, Suspense, useEffect, useState } from 'react'
import { CloseIcon, ExternalIcon, GitHubIcon } from './Icons.jsx'
import './ProjectWindow.css'

// Projects rebuilt to run right here, in the browser
const DEMOS = {
  campusconnect: lazy(() => import('../demos/campusconnect/CampusConnect.jsx')),
}

// Live sites can run inside the window; GitHub repos can't, so they show a preview
const isLive = (p) => p.link && !/github\.com/.test(p.link)
const prettyUrl = (u) => u.replace(/^https?:\/\//, '').replace(/\/$/, '')

export default function ProjectWindow({ project: p, index, total, onClose, onStep }) {
  const [loaded, setLoaded] = useState(false)
  const [about, setAbout] = useState(false)
  const [slow, setSlow] = useState(false)
  const Demo = p.demo && DEMOS[p.demo]
  const live = isLive(p) || Boolean(Demo)
  const d = p.details || {}

  useEffect(() => {
    // On phones, a project with nothing to run opens on its details instead of an empty window
    const narrow = window.matchMedia?.('(max-width: 900px)').matches
    setLoaded(false); setAbout(Boolean(narrow && !isLive(p) && !p.demo)); setSlow(false)
    const t = setTimeout(() => setSlow(true), 8000)
    return () => clearTimeout(t)
  }, [p.name])

  useEffect(() => {
    const onKey = (e) => {
      if (e.key === 'Escape') onClose()
      if (e.target.tagName === 'INPUT') return
      if (e.key === 'ArrowRight') onStep(1)
      if (e.key === 'ArrowLeft') onStep(-1)
    }
    window.addEventListener('keydown', onKey)
    const prev = document.body.style.overflow
    document.body.style.overflow = 'hidden'
    return () => {
      window.removeEventListener('keydown', onKey)
      document.body.style.overflow = prev
    }
  }, [onClose, onStep])

  return (
    <div className="pw" role="dialog" aria-modal="true" aria-label={p.name} onClick={(e) => e.target === e.currentTarget && onClose()}>
      <div className={`pw-layout ${about ? 'show-about' : ''}`}>
        <div className="pw-window" style={{ viewTransitionName: 'vt-hero' }}>
          <div className="pw-bar">
            <span className="pw-dots" aria-hidden="true"><i /><i /><i /></span>
            <span className="pw-url">
              {isLive(p) ? <><span className="pw-lock" aria-hidden="true">●</span>{prettyUrl(p.link)}</> : Demo ? `${p.name}, running in your browser` : p.name}
            </span>
            <span className="pw-bar-actions">
              {(p.link || p.code) && (
                <a href={p.link || p.code} target="_blank" rel="noreferrer" aria-label="Open in a new tab" title="Open in a new tab"><ExternalIcon /></a>
              )}
              <button onClick={onClose} aria-label="Close"><CloseIcon /></button>
            </span>
          </div>
          <div className="pw-screen">
            {Demo ? (
              <Suspense fallback={<div className="pw-loading"><span>Starting {p.name}…</span></div>}>
                <Demo />
              </Suspense>
            ) : isLive(p) ? (
              <>
                {!loaded && (
                  <div className="pw-loading">
                    {p.thumb && <img src={p.thumb} alt="" />}
                    {slow ? (
                      <>
                        <span>{p.name} is taking a while to load here.</span>
                        <a className="pw-primary" href={p.link} target="_blank" rel="noreferrer">Open it in a new tab <ExternalIcon /></a>
                      </>
                    ) : <span>Launching {p.name}…</span>}
                  </div>
                )}
                <iframe
                  key={p.link}
                  src={p.link}
                  title={`${p.name}, running live`}
                  onLoad={() => setLoaded(true)}
                  sandbox="allow-scripts allow-same-origin allow-forms allow-popups"
                  loading="eager"
                />
              </>
            ) : (
              <div className="pw-static">
                {p.thumb && <img src={p.thumb} alt={`${p.name} preview`} />}
              </div>
            )}
          </div>
        </div>

        <aside className="pw-about">
          <p className="pw-kicker">
            Project {index + 1} of {total}
            {live && <span className="pw-live">Running live</span>}
          </p>
          <h2>{p.name}</h2>
          <p className="pw-cat">{p.category.join(' and ')}</p>
          <p>{d.overview || p.description}</p>
          {d.features?.length > 0 && (
            <ul>{d.features.slice(0, 4).map((f) => <li key={f}>{f}</li>)}</ul>
          )}
          <div className="pw-stack">{p.stack.map((t) => <span key={t}>{t}</span>)}</div>
          <div className="pw-actions">
            {p.link && <a className="pw-primary" href={p.link} target="_blank" rel="noreferrer">{isLive(p) ? 'Open full site' : 'View on GitHub'} <ExternalIcon /></a>}
            {p.code && <a className="pw-ghost" href={p.code} target="_blank" rel="noreferrer"><GitHubIcon /> Code</a>}
          </div>
        </aside>
      </div>

      <nav className="pw-nav">
        <button onClick={() => onStep(-1)}>← Previous</button>
        <button className="pw-toggle" onClick={() => setAbout((a) => !a)}>{about ? 'Back to the app' : 'About this project'}</button>
        <button onClick={() => onStep(1)}>Next →</button>
      </nav>
    </div>
  )
}
