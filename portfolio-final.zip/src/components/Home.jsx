import { lazy, Suspense, useEffect, useState } from 'react'
import Orbit from './Orbit.jsx'
import { WorkList, ProjectList } from './Lists.jsx'
import { SunIcon, MoonIcon, GitHubIcon, LinkedInIcon, MailIcon } from './Icons.jsx'
import { profile } from '../data/content.js'
import './Home.css'

// The sky code and star catalog load after the page, only when needed
const SkyBackground = lazy(() => import('../sky/SkyBackground.jsx'))
const LookUp = lazy(() => import('../sky/LookUp.jsx'))
const Meteors = lazy(() => import('../sky/Meteors.jsx'))

// A shared link like ?sky=2026-12-14T03:00:00Z&lat=43.9&lon=-78.9 opens that exact sky
function sharedSky() {
  const q = new URLSearchParams(window.location.search)
  const d = q.get('sky') && new Date(q.get('sky'))
  if (!d || isNaN(d)) return null
  const lat = parseFloat(q.get('lat'))
  const lon = parseFloat(q.get('lon'))
  const place = Number.isFinite(lat) && Number.isFinite(lon) ? { name: 'you', lat, lon, custom: true } : null
  return { date: d, place }
}

const searchable = (title, ...parts) => ({
  'data-search-title': title,
  'data-search': parts.flat().filter(Boolean).join(' '),
})

// OTU webring prev/next need this site's hostname
function useRing() {
  const [ring, setRing] = useState({ prev: 'https://otu-ring.com', next: 'https://otu-ring.com' })
  useEffect(() => {
    const host = window.location.hostname.replace(/^www\./, '')
    if (!host.includes('.')) return
    const from = encodeURIComponent(host)
    setRing({ prev: `https://otu-ring.com/prev.html?from=${from}`, next: `https://otu-ring.com/next.html?from=${from}` })
  }, [])
  return ring
}

export default function Home({ theme, onToggleTheme }) {
  const ring = useRing()
  const [shared] = useState(sharedSky)
  const [looking, setLooking] = useState(!!shared)

  return (
    <div className="page">
      <Suspense fallback={null}>
        {theme === 'dark' && <SkyBackground />}
        {theme === 'dark' && <Meteors />}
        {looking && <LookUp initial={shared} onClose={() => setLooking(false)} />}
      </Suspense>

      <button className="theme" onClick={onToggleTheme} aria-label={theme === 'dark' ? 'Switch to light mode' : 'Switch to dark mode'}>
        {theme === 'dark' ? <SunIcon /> : <MoonIcon />}
      </button>

      <header className="top">
        <div className="intro">
          <h1>{profile.fullName}</h1>
          <p className="sub">{profile.title}</p>
          <p className="school">
            <img src="./logos/otu_logo.jpg" alt="" /> Computer Science at Ontario Tech, graduating December 2027
          </p>
          <p className="blurb">
            Software developer co-op at OPG Darlington, building tools nuclear operators use every shift, and founder of Ghostless. Minoring in math and astronomy, so I spend a lot of time looking up.
          </p>
          <nav className="links" aria-label="Find me">
            <a href={profile.github} target="_blank" rel="noreferrer"><GitHubIcon /> GitHub</a>
            <a href={profile.linkedin} target="_blank" rel="noreferrer"><LinkedInIcon /> LinkedIn</a>
            <a href={`mailto:${profile.email}`}><MailIcon /> Email</a>
            <a href={profile.resume} target="_blank" rel="noreferrer">Résumé</a>
            <button type="button" className="look" onClick={() => setLooking(true)}>
              <span className="look-dot" /> Look up
            </button>
          </nav>
        </div>
        <Orbit photo={profile.avatar} name={profile.fullName} onLookUp={() => setLooking(true)} />
      </header>

      <section>
        <h2>Work</h2>
        <WorkList />
      </section>

      <section>
        <h2>Projects</h2>
        <ProjectList />
      </section>

      <section>
        <h2>Off the clock</h2>
        <p className="life" {...searchable('Off the clock', 'tennis badminton astronomy investing investment portfolio languages')}>
          Learning tennis (the backhand is a work in progress), playing badminton singles, minoring in astronomy,
          and managing my own investment portfolio. I speak English, Urdu, Hindi and Punjabi.{' '}
          {theme === 'dark'
            ? 'The stars behind this page are the real sky over Durham Region, right now.'
            : 'Switch to dark mode to see the real sky over Durham Region behind this page.'}
        </p>
      </section>

      <footer className="foot">
        <span>© {new Date().getFullYear()} {profile.fullName}</span>
        <span className="ring">
          <a href={ring.prev} aria-label="Previous site in the OTU webring">←</a>
          <a href="https://otu-ring.com" target="_blank" rel="noreferrer">OTU webring</a>
          <a href={ring.next} aria-label="Next site in the OTU webring">→</a>
        </span>
      </footer>
    </div>
  )
}
